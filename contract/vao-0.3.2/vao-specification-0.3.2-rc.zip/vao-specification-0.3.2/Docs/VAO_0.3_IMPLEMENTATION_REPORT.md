# VAO 0.3.2 implementation and thesis-update report

Date: 2026-08-24  
Implementation status: complete editor's-draft update  
Public-standard status: not approved or publication-ready  
Thesis sources: deliberately not edited

## 1. Executive outcome

The VAO update to format version `0.3.2` has been implemented as a pre-public correction to the breaking 0.3 compatibility line while preserving the complete VAO 0.2.2 reader, writer, schema, fixtures, migration history, and conformance behavior. The unpublished 0.3.0 snapshot is deliberately superseded; historical published Sandbox bytes were not changed.

The central result is an immutable semantic release that can be carried and materialized in different ways without changing scientific identity, plus a closed position-registered visual-acoustic scene contract. The implementation separates:

- a logical asset and its scientific meaning;
- an exact byte realization;
- an optional distribution of those bytes;
- the repository record used for a distribution;
- the particular `.vao` carrier and its embedded population;
- a local runtime materialization receipt.

For acoustic scenes it additionally separates stable source/receiver measurement identity from the storage layout of any WAVE, SOFA, HDF5, netCDF, Zarr, or custom realization. Geometry realizations declare their own coordinate frames and transformations, so preservation/simulation geometry and a Blender-ready glTF derivative can be proven to occupy the same scene without conflating their purpose.

Repository use is optional. A DOI, network connection, and Zenodo are not required by VAO Core or by the general 0.3 carrier model. A fully embedded package is conforming for development, local testing, private sharing, air-gapped use, and preservation. Zenodo is implemented and tested as one optional repository adapter.

The earlier supplied Zenodo Sandbox credential authenticated successfully during the 0.3.0 adapter campaign. It was used only through ephemeral process input, was never written to a source file or report, and is not reproduced here. The 0.3.2 evaluation used anonymous read-only record access and made no new deposit or metadata mutation.

## 2. Status vocabulary

It is important to distinguish completion of the requested implementation from public standardization:

| State | Result |
| --- | --- |
| 0.3 architecture and normative candidate artifacts | Complete |
| Python reference implementation | Complete for validation, carrier writing, migration, receipts, and optional Zenodo resolution |
| Swift reference implementation | Complete for models, format dispatch, semantic/carrier validation, and side-effect-free materialization planning |
| Repository-free/private operation | Passing |
| Optional Zenodo Sandbox publication and anonymous resolution | Historical 0.3.0 evidence remains passing and immutable |
| Single-record/family topology and Zenodo metadata projection | Complete in schemas, examples, Python, and Swift |
| 0.2 compatibility regression | Passing |
| Deterministic editor's-draft bundle | Passing |
| Approved public standard | Not yet; governance and infrastructure gates remain |
| Production Zenodo/community release | Not attempted; not justified by current maturity or metadata authority |

“Complete” in this report therefore means the 0.3 editor's-draft source set, reference implementations, migration, fixtures, tests, Sandbox evidence, and release-candidate bundle are complete. It does not claim authority that the repository does not yet possess.

## 3. Normative candidate source set

### Specification and policy

- `Docs/VAO_STANDARD_0.3.md` — 0.3 normative candidate, identity model, container, manifest, repository-neutral distribution, groups, profiles, security, preservation, and migration.
- `Docs/VAO_CONFORMANCE_0.3.md` — conformance classes and mandatory positive/negative checks.
- `Docs/VAO_ZENODO_PROFILE_0.3.md` — optional adapter profile, exact DOI/record/file resolution, record-family policy, and discovery boundaries.
- `Docs/VAO_0.2_TO_0.3_MIGRATION.md` — lossless, non-destructive migration contract.
- `Docs/VAO_0.3.2_CHANGELOG.md` — evaluation decision, exact normative changes, compatibility treatment, and thesis boundary.
- `Docs/VAO_ACOUSTIC_SCENES_0.3.md` — public-dataset evaluation, reference mapping, and producer/consumer implementation guide.
- `Docs/VAO_RELEASE_CHECKLIST_0.3.md` — completed implementation gates and unresolved public-release gates.
- `Docs/VAO_GOVERNANCE.md` and `CHANGELOG.md` — compatibility-line and maturity status updated without invalidating 0.2.

### Schemas and semantic resources

- `Schemas/vao-manifest-0.3.schema.json`
- `Schemas/vao-carrier-0.3.schema.json`
- `Schemas/vao-release-0.3.schema.json`
- `Schemas/vao-pack-manifest-0.3.schema.json`
- `Schemas/vao-materialization-receipt-0.3.schema.json`
- `Schemas/vao-zenodo-metadata-0.3.schema.json`
- `Schemas/vao-context-0.3.jsonld`
- `Schemas/vao-vocabulary-0.3.ttl`

All six JSON records are root schemas rather than fragments. The 0.2 generic filenames remain routed to the 0.2 compatibility line; versioned 0.3 files use the 0.3 schema and context IRIs and exact `formatVersion: "0.3.2"` dispatch.

### Reference implementations

- `Tools/vao03.py` — strict JSON, schema and semantic validation, safe workspace/archive validation, deterministic carrier writing, receipts, descriptor validation, and 0.2 migration.
- `Tools/vao03_zenodo.py` — optional resolver with compiled local production/Sandbox trust configuration. The manifest cannot override API bases, allowed hosts, redirects, credentials, or transport policy.
- `Tools/vaom.py` — format dispatch and 0.3 migration/pack/receipt entry points while retaining 0.2 behavior.
- `Sources/OrgRecCore/VAO03Models.swift` — separate 0.3 native model line and format dispatcher.
- `Sources/OrgRecCore/VAO03Validation.swift` — native semantic and carrier checks.
- `Sources/OrgRecCore/VAO03AcousticsValidation.swift` — native coordinate, pose, response-layout, scene-registration, and capability checks.
- `Sources/OrgRecCore/VAO03PackageAccess.swift` — streaming carrier/fixity reader, lossless workspace and realization extraction, and typed visual-acoustic scene inspection.
- `Sources/OrgRecCore/VAO03Materialization.swift` — dependency expansion, capability checks, selection-set enforcement, byte budgeting, and embedded/remote acquisition planning without network or cache side effects.

### Fixtures and descriptors

- `Fixtures/VAO03/valid/embedded-private` — the proof that no repository, DOI, network, or Zenodo is required.
- `Fixtures/VAO03/valid/zenodo-sandbox` — bootstrap plus one optional exact remote realization.
- `Fixtures/VAO03/valid/acousticrooms-scene` — CC BY 4.0 public room geometry, exact simulated RIR/source/receiver positions, provenance evidence, and a Blender-generated GLB derivative in a preservation-closure carrier.
- `Fixtures/VAO03/descriptors/pack-manifest.example.json` — self-hash-free exact pack inventory.
- `Fixtures/VAO03/descriptors/materialization-receipt.example.json` — runtime state outside the semantic manifest.
- `Fixtures/VAO03/descriptors/release-single-record.example.json` and `zenodo-metadata-single-record.example.json` — preferred modular record and full metadata projection.
- `Fixtures/VAO03/descriptors/release-record-family.example.json` plus root/model/audio metadata projections — exclusive and shared member semantics.
- `Release/VAO03Sandbox` — immutable historical 0.3.0 adapter evidence, not a current 0.3.2 release descriptor.

## 4. Final 0.3 architecture

### 4.1 Semantic release and carrier

`vao-manifest.json` is the carrier-independent semantic release. It identifies the conceptual VAO, release, graph, logical assets, exact realizations, optional distributions, groups, rights, and profile states. It contains no embedded path and no runtime instance ID.

`META-INF/vao-carrier.json` identifies one carrier as `bootstrap`, `preservation-closure`, or `custom`. It pins the exact manifest bytes and maps realization IDs to the `payload/` paths actually embedded in this carrier. Every payload file is mapped exactly once and verified against the realization's byte size and SHA-256.

This resolves the bootstrap-versus-preservation identity problem. Two carriers can contain identical manifest bytes and represent the same release even when one embeds a preview and another embeds the full preservation closure.

### 4.2 Logical assets and realizations

A logical asset captures scientific meaning, roles, and subjects. A realization captures one exact encoding and byte sequence. Representation status, provenance, rights, technical metadata, media type, byte size, and SHA-256 are realization-level because different encodings or derivations can have materially different epistemic and reuse status.

Audio technical metadata includes mandatory sample rate and channel count. Ambisonics metadata additionally declares order, dimensionality, ACN order, and SN3D or N3D normalization; validators verify the expected channel count. Geometry metadata includes a resolved coordinate frame, unit IRI, handedness, up axis, and LOD.

### 4.3 Position-registered visual-acoustic scenes

The 0.3.1 schema accepted an opaque `acoustics` object, which preserved bytes but could not validate spatial meaning. Version 0.3.2 restores a closed technical model with nine registries and adds stable source–receiver measurements. Response sets identify scientific meaning; each audio realization supplies the exact measurement-to-data/channel mapping, sample count, encoding, convention, time-zero policy, and normalization. WAVE/FLAC are restricted to one fixed pair, while SOFA can map its `M` dimension explicitly.

Coordinate frames form an acyclic, invertible transform graph. Poses resolve entities and frames, geometry bindings resolve logical spatial-model assets, and the `visual-acoustic-scene` capability is accepted only when the mesh and measurements share a coordinate root. Simulated/measured/hybrid capability claims are checked against the response status and generating evidence.

The reference case selects `Bathrooms_idx_0/S000_R0011` from AcousticRooms at commit `3c87318a0188e1b441fc75846d54b487ca215fbb`. It fixes exact upstream object/member hashes, the CC BY 4.0 license and README, OBJ geometry, pair/config metadata, and a 22,050 Hz mono hybrid RIR. Exact source and receiver positions are retained. Blender 5.1.1 produced a separate GLB visualization realization; the manifest records its +Y-up frame and exact transform into the +Z-up dataset frame. No Blender add-on modification is required to prove that the standard can represent this workflow.

### 4.4 Distributions and local trust

A realization can have no distribution when it is intended only for embedded exchange. A remotely materializable realization has one or more exact distributions. Multiple distributions are mirrors only if the realization hash and size are identical.

A repository distribution contains a repository binding, exact version persistent identifier, record identifier, file identifier, and access state. It cannot contain a credential, arbitrary URL, API base, allowed host, redirect policy, or user-consent decision. Those remain local client configuration.

### 4.5 Groups and profile states

Groups have selection-set identity, independent or exclusive selection policy, dependency groups, optional fallback, exact unique byte totals, capability requirements, profile effects, and cache priority. Dependency and fallback graphs must be acyclic.

`profiles` contains claims satisfied by the embedded bootstrap. `materializableProfiles` contains claims that become complete only after named groups and dependencies are acquired and verified. Availability, authentication, local-policy rejection, and integrity failure remain separate operational states.

### 4.6 Repository neutrality

The manifest registries `distributions` and `repositoryBindings` are required so absence is explicit, but both may be empty. Dynamic Delivery is the general release/carrier/realization model; it does not mean “download from Zenodo.”

The optional Zenodo profile is claimed if and only if a Zenodo binding is present. Other repository adapters can implement the same exact-version and exact-byte contract without changing VAO Core. Fully embedded carriers need no adapter profile.

### 4.7 Publication topology and metadata

Publication now defaults to one modular record with independently downloadable files. This places the manifest, bootstrap carrier, 3D/audio realizations or coherent packs, checksums, documentation, and metadata in one citable unit when repository limits, access, rights, and update lifecycle permit it. It does not require a giant ZIP.

A record family is optional and explicit. Exclusive members use `hasPart`/`isPartOf`; reusable records use the true dependency or reference semantics and need not claim one inverse owner. All dependency relations use exact version PIDs. The concept DOI remains an update channel.

The Zenodo projection makes systematic use of creators, contributors, publication date, version, access/license fields, keywords/subjects, dates/method, references, notes, communities/grants when applicable, and `related_identifiers`. It is an optional publication adapter artifact, not a new Core requirement.

## 5. Resolution of the evaluated blueprint issues

| Evaluated issue | 0.3 resolution |
| --- | --- |
| Schema was only a `$defs` fragment | Replaced by five complete root schemas with exact `$id`, required root fields, and closed records |
| Example fields were rejected by its own schema | Canonical fixtures validate against the implemented schema and semantic validator |
| Strict 0.2 bridge used wrong schema/profile claims | Replaced by executable non-destructive 0.2-to-0.3 migration; 0.2 never claims remote completion |
| Receipt referenced a nonexistent/different realization | New receipt example is generated from and hash-consistent with the corrected Sandbox manifest |
| Asset-group byte totals were inconsistent | Totals are recomputed and semantically enforced from unique realization IDs |
| Pack DOI/file/size/member inventory conflicted | Pack schema separates outer realization from member inventory, rejects unlisted members, and avoids a self-hash |
| 0.3 reused 0.2 profile IRIs | Every 0.3 profile has a new `/0.3` IRI; reuse is a negative test |
| Runtime `instanceId` appeared in immutable manifest | Runtime identity occurs only in the materialization receipt |
| Bootstrap and preservation carrier identity was unresolved | Carrier descriptor separates population from semantic release identity |
| Generic repository object embedded Zenodo behavior | Core binding is repository-neutral; Zenodo is an optional adapter profile |
| Package could widen network trust | API bases, host allowlists, credentials, redirects, and consent are local adapter policy |
| Representation status/provenance/rights were too coarse | All are realization-level and rights coverage is validated |
| Root/pack inverse relation prevented reusable packs | Exclusive members use `hasPart`/`isPartOf`; reusable packs use `requires` or another truthful relation without false ownership |
| Release descriptor lacked topology and complete pins | Release schema declares one-record/family topology and exact typed file inventories for every record |
| Zenodo metadata was under-specified | A separate optional metadata schema and cross-validator project creators, rights/access, discovery fields, and exact PID relations |
| Concept DOI could be used at runtime | Exact resolution requires version DOI, record ID, file key, byte size, and SHA-256; equality with concept DOI is rejected |

The original blueprint in `/Users/dominik/Downloads/vao_zenodo_blueprint` remains research/evaluation input and was not promoted as normative source.

## 6. Compatibility and migration

VAO 0.2.2 remains a valid, separate line. The generic 0.2 schema/context/vocabulary and the established Swift/Python implementation were not relabeled as 0.3.

The migration command is:

```sh
python3 Tools/vaom.py migrate-0.2 SOURCE_WORKSPACE DESTINATION_WORKSPACE
```

For packages without the Spatial/Acoustics model, it requires a valid 0.2.2 workspace, refuses an existing destination, preserves graph/paradata/analysis data, creates one logical asset and realization for each old indexed asset, moves the physical path into the carrier descriptor, creates only an embedded bootstrap group, maps profiles to new 0.3 IRIs, and records the source manifest SHA-256. It does not invent repository bindings, distributions, or materializable claims. An acoustic 0.2 source stops before destination creation because exact response layout and coordinate facts require producer enrichment; this is safer than fabricating 0.3.2 conformance.

## 7. Historical Zenodo Sandbox campaign

### Authentication

The supplied key returned HTTP 200 from the authenticated Sandbox deposit API during the original 0.3.0 work. Had authentication failed, work would have paused as requested.

### First immutable trial

Record `590945` was created from a draft whose `prereserve_doi` reported `10.5281/zenodo.590945`. Publication assigned `10.5072/zenodo.590945` and concept DOI `10.5072/zenodo.590944`. That changed namespace made the manifest's pre-publication self-reference fail the exact DOI contract.

The bytes were not replaced under the published DOI. This failed trial is preserved as evidence of a Sandbox API behavior relevant to reserve-before-publication workflows.

### Corrected version

A new version was created and published as:

- version DOI: `10.5072/zenodo.590947`;
- concept DOI: `10.5072/zenodo.590944`;
- record ID: `590947`;
- content version: `1.0.1-sandbox`;
- status: Sandbox-only CC0 conformance fixture.

Anonymous Records API resolution returned the exact record ID, version DOI, concept DOI, six files, file keys, sizes, MD5 transport checksums, and content links. The optional adapter then resolved `remote-production.txt`, confirmed record ID and DOI, confirmed the exact file key and declared size, downloaded 80 bytes, and verified SHA-256:

`487de76ad66794ffcda3774e07018d421ca73ba10ba1c86295787b732a6456bc`

The downloaded bytes were also byte-for-byte identical to the local source. Zenodo's MD5 was retained only as supplementary repository evidence; SHA-256 from the VAO realization remained authoritative.

Sandbox record: `https://sandbox.zenodo.org/records/590947`

### What the Sandbox trial does and does not prove

It proves the optional adapter mechanics for one small public record: authentication, creation, metadata, upload, publication, versioning, anonymous discovery, exact record/file resolution, and byte fixity.

It does not prove production quotas, community moderation, restricted-access flows, large-file behavior, pack extraction, long-term availability, OAI synchronization, or production DOI reservation behavior. Those remain integration or operational tests, not Core conformance requirements.

For 0.3.2, anonymous read-only access reconfirmed record `590947`, its assigned DOI, metadata, and six-file inventory. No record or metadata was changed. The current monolithic/family examples intentionally use non-resolving example identifiers until a production publication decision is authorized.

## 8. Verification evidence

### Python 0.2 regression

The full strict 0.2 suite was run from a clean copy excluding Finder `.DS_Store` files. Results:

- release check: pass, implementation-ready;
- positive workspaces/archive/migration: pass;
- negative cases: 46 of 46 pass;
- reader compatibility: 0.2.0, 0.2.1, and 0.2.7 accepted under the 0.2 line;
- publication-ready: false for the pre-existing 0.2 governance/license/dependency blockers.

Finder metadata in the working fixture is correctly rejected as unindexed hidden payload; it was not deleted because it is user-owned workspace state.

### Python 0.3 conformance

Fifty-one of fifty-one cases pass before the final bundle build. Coverage includes repository-free and public-data positive validation, exact workspace mimetype bytes, schema/root closure, 0.2 IRI rejection, Core/Dynamic claims, optional Zenodo claim rules, duplicate IDs, graph and inverse references, rights gaps, group totals, dependency/fallback cycles, Ambisonics channel consistency, concept-DOI rejection, carrier/manifest binding, corrupt or hidden payload, unsafe paths, preservation closure, single-record and family topology, exclusive/shared relation rules, concept-PID publication rejection, exact Zenodo relation projection, non-destructive non-acoustic 0.2 migration, explicit acoustic-migration enrichment refusal, carrier packing, receipt validation, coordinate cycles, quaternion normalization, pose/subject agreement, response mappings/channel bounds/status, visual registration, and acoustic capability truth.

### Swift

The focused Swift 0.3 suite passes 14 tests with zero failures. Six public-scene cases validate all eight embedded payloads, assert exact source/receiver positions and sample count, exercise OrgRec streaming inspection/workspace/single-realization extraction, reject corrupt payload bytes, and reject an out-of-range response channel and non-invertible geometry transform. The complete Swift suite passes 85 tests with zero failures.

### Public-data carrier and geometry sanity check

`dist/acousticrooms-bathrooms-idx-0.vao` validates offline as a 0.3.2 preservation closure and two deterministic packs have SHA-256 `54aef8656162f485a0c4aa37dca56accc909284db4f746b33f85500749da2286`. The source OBJ bounds are `(1.79999995, -0.2, 0.0)` to `(3.95000005, 2.29999995, 2.6500001)` metres; both declared source/receiver points lie inside that axis-aligned extent. A clean Blender 5.1.1 import of the GLB contains one mesh named `Bathrooms_idx_0` with 17,429 vertices and 21,760 polygons.

### OrgRec application compatibility

OrgRec now dispatches exact VAO 0.3.2 carriers separately from the editable 0.2.2 OrgRec Capture path. Its streaming reader validates all embedded bytes, imports a lossless read-only workspace under Application Support, extracts individual realizations by ID, and projects frames, poses, source–receiver measurements, geometry, and impulse responses into typed Swift descriptors. The project-library UI summarizes the imported scene and reveals its workspace. It does not misrepresent a room as an editable organ project or claim acoustic/3D rendering. The complete support boundary is documented in `Docs/ORGREC_VAO_0.3.2_COMPATIBILITY.md`.

### Release bundle

`dist/vao-specification-0.3.2-rc.zip` is a deterministic, checksum-pinned editor's-draft bundle. The final checksum must be taken from its adjacent `.sha256` file after the final report is included and the bundle is rebuilt. Its embedded `BUILD_INFO.json` records inventory hashes, conformance results, Sandbox evidence, maturity, and public-release blockers.

## 9. Security properties

- Strict UTF-8 JSON rejects duplicate properties and non-finite numbers.
- ZIP readers reject traversal, links, duplicates, encryption, unknown entries, unsupported compression, and resource-limit violations.
- Exact manifest bytes are pinned outside the manifest to avoid self-hash recursion.
- Payload data is hashed before use and unindexed payload is rejected.
- Repository data downloads to a temporary file, is size-limited and hashed, and is atomically committed only after verification.
- Production and Sandbox adapter identities, API bases, DOI prefixes, and host allowlists are local constants.
- Package-supplied credentials, API overrides, arbitrary URLs, and trust escalation are structurally absent.
- Materialization planning is side-effect-free; network and cache operations remain outside hard-real-time rendering callbacks.
- Published bytes are never edited under the same version DOI by VAO policy, even if repository tooling permits correction.

## 10. Remaining public-release blockers

The implementation is complete, but `publicationReady` remains false. A release authority must resolve:

1. named responsible editor, maintainer, domain reviewer, ontology reviewer, preservation/security reviewer, and independent implementation reviewer;
2. public W3ID ownership and tested redirects for schema, context, vocabulary, profiles, and repository adapter IRIs;
3. approved standard/source license, copyright notice, and contributor policy;
4. media-type registration or an approved registration plan;
5. immutable released MODAVIS ontology, vocabulary, and mapping pins rather than `development` bindings;
6. at least one independent reader/writer and interoperability report;
7. security review of archive, resolver, decompression, cache, and restricted-access behavior;
8. production repository/community metadata, ownership, preservation, and moderation decisions.

These are authority and external-infrastructure requirements. They should not be bypassed by wording the editor's draft as an already approved standard.

## 11. Thesis update plan

No thesis file was edited. The following plan can be applied later to the thesis source in `/Users/dominik/Desktop/thesis-finalization-2/working-state`.

### 11.1 Correct the maturity claim

Replace claims that VAO is already a public or normative standard with precise language:

> VAO 0.3.2 is an implemented private editor's draft and reference implementation evaluated through local conformance tests and an optional Zenodo Sandbox adapter trial. Public namespace, governance, dependency, licensing, media-type, security, and independent-interoperability gates remain open.

Do not call the Sandbox DOI the DOI of “the VAO standard.” It identifies a CC0 conformance fixture for an optional adapter.

### 11.2 Replace the closed-payload-only description

The 0.2 description remains historically correct: every required asset was an indexed `payload/` file. The 0.3 description should say:

> The immutable semantic release identifies exact byte realizations. A carrier descriptor records which realizations a particular `.vao` embeds. Optional repository distributions may materialize other already-declared realizations, while a preservation closure embeds the complete required set. Cache state and receipts do not modify the release.

Avoid describing a thin carrier as a mutable object or a manifest that gains assets after publication.

### 11.3 Explain optionality explicitly

Add a sentence close to the first repository discussion:

> VAO 0.3 does not require a repository, DOI, network, or Zenodo. Fully embedded carriers remain conforming for development, testing, private exchange, air-gapped work, and preservation; Zenodo is one optional adapter.

This prevents the implementation experiment from being mistaken for a mandatory architectural dependency.

### 11.4 Correct profile enumeration

The thesis currently describes six profiles and conflates several names. Scope any count by version and category. The formal 0.2.2 line has eight domain/application profiles: Core Graph, Research, Playable, Spatial, Acoustics, Preservation, Experiential/XR, and OrgRec Capture. VAO 0.3 reserves corresponding `/0.3` IRIs and adds the general Dynamic Delivery profile plus an optional Zenodo adapter profile.

Do not merge Playable with Experiential or Spatial with Acoustics. Do not replace OrgRec Capture with an informal “pipe-organ specialization.”

### 11.5 Correct minimum Core behavior

The formal 0.2.2 Core package is not metadata-only; it requires at least one evidence or representation asset. In 0.3 the bootstrap similarly embeds at least one meaningful exact realization. A manifest-only graph may be useful metadata, but should not be presented as a conforming Core carrier under this source set.

### 11.6 Add the identity table

The thesis should distinguish:

| Identity | Thesis meaning |
| --- | --- |
| conceptual VAO ID | continuing scientific object |
| release ID/revision/content version | exact semantic state and dependency lock |
| manifest SHA-256 | exact JSON serialization |
| carrier SHA-256 | exact `.vao` envelope/population |
| repository version DOI and record ID | exact published repository record |
| concept DOI | update/discovery channel only |
| realization SHA-256 | exact content bytes |
| receipt instance ID | local runtime materialization event |

State explicitly that the concept DOI must not resolve runtime dependencies to “latest.”

### 11.7 Explain repository resolution and fixity

Recommended wording:

> A locally trusted repository adapter resolves the exact version DOI, record ID, and file key. It verifies the realization byte size and VAO SHA-256 before cache commit. Repository MD5 values are supplementary transport evidence. The manifest cannot supply credentials or widen the client's host and redirect allowlists.

Do not use a cached direct download URL as a persistent identifier.

### 11.8 Explain packs without contradictory ownership

Describe root records as pinning exact pack version records and exact pack-manifest bytes. A reusable pack need not claim an exclusive inverse `IsPartOf` relation to one root. Pack manifests enumerate safe member paths, media types, byte sizes, and SHA-256 and reject unlisted members. The outer pack and every extracted member are verified.

### 11.9 Correct the ZIP64 citation

RFC 8493 specifies BagIt, not ZIP64. Cite the current PKWARE ZIP Application Note for ZIP64 mechanics. RFC 8493 can remain only if the thesis actually discusses BagIt packaging. This correction is independent of the VAO 0.3 architecture.

### 11.10 Present Zenodo evidence accurately

The thesis may report the Sandbox experiment as an implementation result:

> An optional Zenodo Sandbox adapter was tested through record creation, versioning, publication, anonymous Records API discovery, exact file-key resolution, download, and SHA-256 verification. A draft/publication DOI-prefix discrepancy was detected; immutable bytes were retained and a corrected new version was published at `10.5072/zenodo.590947`.

This is valuable negative as well as positive evidence. It supports the rule that repository responses cannot override manifest fixity and that draft DOI behavior must be tested per environment.

Do not generalize the small Sandbox file test into claims about production large-file performance, restricted access, long-term preservation, or CDN behavior.

### 11.11 Distinguish preservation and availability

Zenodo availability is not equivalent to preservation closure. A preservation carrier embeds all required realizations and representation information and validates offline. The thesis should recommend an independent institutional/archive copy for preservation-sensitive objects.

### 11.12 Update figures and examples

Any architecture figure should show this direction:

`conceptual VAO -> immutable release manifest -> exact realizations -> optional distributions`

and separately:

`release manifest -> bootstrap carrier / preservation carrier / local materialization receipt`

Examples should be generated from the valid `Fixtures/VAO03` source rather than copied from the evaluated blueprint, because the blueprint examples contain mutually inconsistent hashes, byte totals, profile IRIs, and record identities.

### 11.13 Explain publication topology and Zenodo metadata

Recommended wording:

> A published VAO normally uses one modular repository record containing separately downloadable manifest, bootstrap carrier, model, audio/pack, checksum, documentation, and metadata files. A related record family is optional when size/file-count limits, access or licensing, independent update cycles, reuse, ownership, or separate citation justify the split. Exclusive members use `HasPart`/`IsPartOf`; reusable dependencies use relations such as `Requires` without claiming exclusive ownership. Every machine dependency pins the exact version DOI, while the concept DOI is only an update channel.

State that the current Zenodo default of 50 GB and 100 files is an operational planning boundary, not a permanent VAO rule. Explain that the Zenodo record metadata should project creators and contributors, content version, access/license, discovery terms, provenance/method, funding/community context where applicable, and exact `related_identifiers`; it does not replace realization-level rights or VAO fixity.

## 12. Suggested thesis evidence references

Use primary sources for operational statements and record the access date because repository behavior may change:

- Zenodo developer API: `https://developers.zenodo.org/`
- Zenodo file management: `https://help.zenodo.org/docs/deposit/manage-files/`
- Zenodo version management: `https://help.zenodo.org/docs/deposit/manage-versions/`
- Zenodo record behavior: `https://help.zenodo.org/docs/deposit/about-records/`
- Zenodo record description: `https://help.zenodo.org/docs/deposit/describe-records/`
- Zenodo DOI reservation: `https://help.zenodo.org/docs/deposit/describe-records/reserve-doi/`
- BagIt RFC 8493: `https://www.rfc-editor.org/info/rfc8493`
- PKWARE ZIP Application Note: use the current official APPNOTE version at the time of thesis revision.

Where Zenodo help pages appear inconsistent about post-publication file corrections, cite the conflict and state the stricter VAO policy: no byte changes under an existing version DOI.

## 13. Reproducible commands

```sh
# Repository-free 0.3 fixture
python3 Tools/vaom.py validate Fixtures/VAO03/valid/embedded-private

# 0.3 conformance
python3 Tools/test_vao03_conformance.py

# Preferred single-record publication descriptor and Zenodo metadata
python3 Tools/vao03.py validate-publication Fixtures/VAO03/descriptors/release-single-record.example.json Fixtures/VAO03/descriptors/zenodo-metadata-single-record.example.json

# Optional related record family and all root/member metadata projections
python3 Tools/vao03.py validate-publication Fixtures/VAO03/descriptors/release-record-family.example.json Fixtures/VAO03/descriptors/zenodo-metadata-family-root.example.json Fixtures/VAO03/descriptors/zenodo-metadata-family-model.example.json Fixtures/VAO03/descriptors/zenodo-metadata-family-audio.example.json

# 0.2 regression from a clean copy without Finder metadata
python3 Tools/check_vao_release.py --root CLEAN_COPY
python3 Tools/test_vao_conformance.py

# Native implementation
swift test --no-parallel

# Optional anonymous Sandbox metadata check
python3 Tools/vao03_zenodo.py Fixtures/VAO03/valid/zenodo-sandbox/vao-manifest.json urn:uuid:03000000-0000-4000-8000-000000000150 --instance sandbox --metadata-only --json

# Deterministic editor's-draft release bundle
python3 Tools/build_vao03_release.py --force
```

## 14. Thesis non-modification confirmation

No file under `/Users/dominik/Desktop/thesis-finalization-2` was written or modified during this update. The thesis observations and recommended wording in this report are a handoff for a later, separately authorized thesis revision.
