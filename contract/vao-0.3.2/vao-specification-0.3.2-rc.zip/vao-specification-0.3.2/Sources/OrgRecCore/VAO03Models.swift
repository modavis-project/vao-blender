import Foundation

/// The VAO 0.3 line is intentionally separate from `VAOContract` (0.2.2).
/// Readers dispatch by `formatVersion`; existing 0.2 models remain unchanged.
public enum VAO03Contract {
    public static let formatVersion = "0.3.2"
    public static let spatialProfile = "https://w3id.org/modavis/vao/profile/spatial/0.3"
    public static let acousticsProfile = "https://w3id.org/modavis/vao/profile/acoustics/0.3"
    public static let mediaType = "application/vnd.modavis.vao+zip"
    public static let manifestFilename = "vao-manifest.json"
    public static let carrierFilename = "META-INF/vao-carrier.json"
    public static let schemaURI = "https://w3id.org/modavis/vao/0.3/schema/manifest.json"
    public static let releaseSchemaURI = "https://w3id.org/modavis/vao/0.3/schema/release.json"
    public static let zenodoMetadataSchemaURI = "https://w3id.org/modavis/vao/0.3/schema/zenodo-metadata.json"
    public static let contextURI = "https://w3id.org/modavis/vao/0.3/context.jsonld"
    public static let coreProfile = "https://w3id.org/modavis/vao/profile/core/0.3"
    public static let dynamicDeliveryProfile = "https://w3id.org/modavis/vao/profile/dynamic-delivery/0.3"
    public static let zenodoProfile = "https://w3id.org/modavis/vao/profile/repository/zenodo/0.3"
    public static let zenodoRepositoryType = "https://w3id.org/modavis/vao/repository/zenodo"
}

public struct VAO03Manifest: Codable, Sendable, Equatable {
    public var schema: String
    public var context: [String]
    public var type: String
    public var formatVersion: String
    public var id: String
    public var release: VAO03ReleaseIdentity
    public var createdAt: String
    public var modifiedAt: String
    public var title: [String: String]
    public var description: [String: String]?
    public var conformsTo: [String]
    public var profiles: [VAO03Profile]
    public var materializableProfiles: [VAO03MaterializableProfile]
    public var modavisBinding: VAO03ModavisBinding
    public var primaryEntityId: String
    public var focusEntityIds: [String]
    public var entities: [VAO03Entity]
    public var relations: [VAO03Relation]
    public var paradata: [VAOJSONValue]
    public var analyses: [VAOJSONValue]
    public var acoustics: VAOJSONValue?
    public var logicalAssets: [VAO03LogicalAsset]
    public var realizations: [VAO03Realization]
    public var distributions: [VAO03Distribution]
    public var repositoryBindings: [VAO03RepositoryBinding]
    public var assetGroups: [VAO03AssetGroup]
    public var rights: [VAO03Rights]
    public var integrity: VAO03Integrity
    public var extensions: [String: VAOJSONValue]?

    enum CodingKeys: String, CodingKey {
        case schema = "$schema"
        case context = "@context"
        case type, formatVersion, id, release, createdAt, modifiedAt, title, description, conformsTo, profiles
        case materializableProfiles, modavisBinding, primaryEntityId, focusEntityIds, entities, relations, paradata
        case analyses, acoustics, logicalAssets, realizations, distributions, repositoryBindings, assetGroups, rights
        case integrity, extensions
    }
}

public struct VAO03ReleaseIdentity: Codable, Sendable, Equatable {
    public var id: String
    public var revision: Int
    public var contentVersion: String
    public var supersedesReleaseId: String?
    public var migratedFromManifestSHA256: String?
}

public struct VAO03Profile: Codable, Sendable, Equatable {
    public var id: String
    public var version: String
    public var requiredCapabilities: [String]
}

public struct VAO03MaterializableProfile: Codable, Sendable, Equatable {
    public var id: String
    public var version: String
    public var requiredCapabilities: [String]
    public var groupIds: [String]
}

public struct VAO03ModavisBinding: Codable, Sendable, Equatable {
    public var ontologyIRI: String
    public var ontologyVersion: String
    public var ontologyStatus: String
    public var ontologyVersionIRI: String?
    public var mappingVersion: String
    public var mappingIRI: String?
    public var vocabularyReleaseIRI: String?
    public var vocabularyManifestSHA256: String?
    public var notes: String?
}

public struct VAO03Entity: Codable, Sendable, Equatable {
    public var id: String
    public var kind: String
    public var types: [String]
    public var labels: [String: String]
    public var classifications: [VAOJSONValue]?
    public var externalIdentifiers: [VAOJSONValue]?
    public var properties: [String: VAOJSONValue]?
}

public struct VAO03Relation: Codable, Sendable, Equatable {
    public var id: String
    public var subjectId: String
    public var predicate: String
    public var objectId: String?
    public var literal: VAOJSONValue?
    public var status: String
    public var confidence: Double?
    public var scope: VAOJSONValue?
    public var evidenceIds: [String]?
    public var generatedByIds: [String]?
    public var properties: [String: VAOJSONValue]?
}

public struct VAO03LogicalAsset: Codable, Sendable, Equatable {
    public var id: String
    public var type: String
    public var labels: [String: String]?
    public var roles: [String]
    public var aboutEntityIds: [String]
    public var realizationIds: [String]
    public var properties: [String: VAOJSONValue]?
}

public struct VAO03Realization: Codable, Sendable, Equatable {
    public var id: String
    public var type: String
    public var assetId: String
    public var variantSetId: String
    public var qualityTier: String
    public var mediaType: String
    public var byteSize: Int64
    public var sha256: String
    public var representationStatus: String
    public var rightsIds: [String]
    public var provenanceIds: [String]
    public var technicalMetadata: VAO03TechnicalMetadata
    public var distributionIds: [String]
}

public struct VAO03TechnicalMetadata: Codable, Sendable, Equatable {
    public var kind: String
    public var sampleRate: Double?
    public var sampleFormat: String?
    public var bitDepth: Int?
    public var channelCount: Int?
    public var channelLabels: [String]?
    public var audioContainer: String?
    public var ambisonicsOrder: Int?
    public var ambisonicsDimensionality: String?
    public var ambisonicsChannelOrder: String?
    public var ambisonicsNormalization: String?
    public var impulseResponse: VAOJSONValue?
    public var coordinateFrameId: String?
    public var coordinateUnit: String?
    public var handedness: String?
    public var upAxis: String?
    public var lod: Int?
    public var triangleCount: Int64?
    public var vertexCount: Int64?
    public var textureMaxDimension: Int?
    public var purposeLimitations: [String]?
    public var extensions: [String: VAOJSONValue]?
}

/// Closed union represented with optional variant fields so unknown repository
/// adapters do not require Swift enum rewrites. The validator enforces the
/// fields allowed and required for `repository` and `pack-member`.
public struct VAO03Distribution: Codable, Sendable, Equatable {
    public var id: String
    public var kind: String
    public var repositoryBindingId: String?
    public var persistentIdentifier: String?
    public var conceptIdentifier: String?
    public var recordIdentifier: String?
    public var fileIdentifier: String?
    public var access: String?
    public var transportChecksums: [String: String]?
    public var packRealizationId: String?
    public var memberPath: String?
    public var packManifestSHA256: String?
}

public struct VAO03RepositoryBinding: Codable, Sendable, Equatable {
    public var id: String
    public var repositoryType: String
    public var instance: String
    public var apiProfile: String
    public var resolutionPolicy: String
}

public struct VAO03AssetGroup: Codable, Sendable, Equatable {
    public var id: String
    public var type: String
    public var labels: [String: String]
    public var selectionSetId: String
    public var qualityTier: String
    public var availability: String
    public var selectionPolicy: String
    public var realizationIds: [String]
    public var dependsOnGroupIds: [String]
    public var fallbackGroupId: String?
    public var totalByteSize: Int64
    public var requiredCapabilities: [String]
    public var materializesProfileIds: [String]
    public var cachePolicy: VAO03CachePolicy
}

public struct VAO03CachePolicy: Codable, Sendable, Equatable {
    public var evictable: Bool
    public var priority: Int
}

public struct VAO03Rights: Codable, Sendable, Equatable {
    public var id: String
    public var appliesToIds: [String]
    public var license: String?
    public var statement: [String: String]
    public var access: String
    public var attribution: String?
}

public struct VAO03Integrity: Codable, Sendable, Equatable {
    public var algorithm: String
    public var manifestDigestLocation: String
    public var carrierDescriptor: String
}

public struct VAO03Carrier: Codable, Sendable, Equatable {
    public var schema: String
    public var type: String
    public var formatVersion: String
    public var releaseId: String
    public var manifestSHA256: String
    public var manifestByteSize: Int64
    public var carrierMode: String
    public var embeddedRealizations: [VAO03CarrierMapping]
    public var completeGroupIds: [String]

    enum CodingKeys: String, CodingKey {
        case schema = "$schema"
        case type, formatVersion, releaseId, manifestSHA256, manifestByteSize, carrierMode
        case embeddedRealizations, completeGroupIds
    }
}

public struct VAO03CarrierMapping: Codable, Sendable, Equatable {
    public var realizationId: String
    public var path: String
}

public struct VAO03ReleaseDescriptor: Codable, Sendable, Equatable {
    public var schema: String
    public var type: String
    public var formatVersion: String
    public var vaoId: String
    public var releaseId: String
    public var revision: Int
    public var contentVersion: String
    public var publication: VAO03Publication

    enum CodingKeys: String, CodingKey {
        case schema = "$schema"
        case type, formatVersion, vaoId, releaseId, revision, contentVersion, publication
    }
}

public struct VAO03Publication: Codable, Sendable, Equatable {
    public var topology: String
    public var rootRecord: VAO03PublicationRecord
    public var familyMembers: [VAO03FamilyMember]
}

public struct VAO03PublicationRecord: Codable, Sendable, Equatable {
    public var id: String
    public var repositoryType: String
    public var instance: String
    public var versionPersistentIdentifier: String
    public var conceptPersistentIdentifier: String?
    public var recordIdentifier: String
    public var files: [VAO03PublicationFile]
}

public struct VAO03PublicationFile: Codable, Sendable, Equatable {
    public var fileIdentifier: String
    public var role: String
    public var byteSize: Int64
    public var sha256: String
    public var realizationIds: [String]?
}

public struct VAO03FamilyMember: Codable, Sendable, Equatable {
    public var recordRole: String
    public var membership: String
    public var relationFromRoot: String
    public var inverseRelationFromMember: String?
    public var record: VAO03PublicationRecord
}

public struct VAO03ZenodoMetadataDocument: Codable, Sendable, Equatable {
    public var schema: String
    public var type: String
    public var formatVersion: String
    public var releaseId: String
    public var publicationRecordId: String
    public var recordRole: String
    public var metadata: VAO03ZenodoMetadata

    enum CodingKeys: String, CodingKey {
        case schema = "$schema"
        case type, formatVersion, releaseId, publicationRecordId, recordRole, metadata
    }
}

public struct VAO03ZenodoMetadata: Codable, Sendable, Equatable {
    public var uploadType: String
    public var title: String
    public var description: String
    public var creators: [VAO03ZenodoPerson]
    public var contributors: [VAO03ZenodoContributor]?
    public var publicationDate: String
    public var version: String
    public var accessRight: String
    public var license: String?
    public var embargoDate: String?
    public var accessConditions: String?
    public var keywords: [String]
    public var relatedIdentifiers: [VAO03ZenodoRelatedIdentifier]
    public var communities: [VAO03ZenodoCommunity]?
    public var grants: [VAO03ZenodoGrant]?
    public var references: [String]?
    public var subjects: [VAO03ZenodoSubject]?
    public var dates: [VAO03ZenodoDate]?
    public var language: String?
    public var notes: String?
    public var method: String?

    enum CodingKeys: String, CodingKey {
        case uploadType = "upload_type"
        case title, description, creators, contributors
        case publicationDate = "publication_date"
        case version
        case accessRight = "access_right"
        case license
        case embargoDate = "embargo_date"
        case accessConditions = "access_conditions"
        case keywords
        case relatedIdentifiers = "related_identifiers"
        case communities, grants, references, subjects, dates, language, notes, method
    }
}

public struct VAO03ZenodoPerson: Codable, Sendable, Equatable {
    public var name: String
    public var affiliation: String?
    public var orcid: String?
    public var gnd: String?
}

public struct VAO03ZenodoContributor: Codable, Sendable, Equatable {
    public var name: String
    public var affiliation: String?
    public var orcid: String?
    public var gnd: String?
    public var type: String
}

public struct VAO03ZenodoRelatedIdentifier: Codable, Sendable, Equatable {
    public var identifier: String
    public var relation: String
    public var resourceType: String?

    enum CodingKeys: String, CodingKey {
        case identifier, relation
        case resourceType = "resource_type"
    }
}

public struct VAO03ZenodoCommunity: Codable, Sendable, Equatable { public var identifier: String }
public struct VAO03ZenodoGrant: Codable, Sendable, Equatable { public var id: String }
public struct VAO03ZenodoSubject: Codable, Sendable, Equatable { public var term: String; public var identifier: String; public var scheme: String }
public struct VAO03ZenodoDate: Codable, Sendable, Equatable { public var start: String; public var end: String?; public var type: String; public var description: String? }

public enum VAOFormatDispatcher {
    public static func formatVersion(in data: Data) -> String? {
        guard let root = try? JSONSerialization.jsonObject(with: data) as? [String: Any] else { return nil }
        return root["formatVersion"] as? String
    }

    public static func decode03(_ data: Data, decoder: JSONDecoder = JSONDecoder()) throws -> VAO03Manifest {
        try decoder.decode(VAO03Manifest.self, from: data)
    }
}
