import Foundation
import XCTest
@testable import OrgRecCore

final class VAO03Tests: XCTestCase {
    private var fixture: URL {
        URL(fileURLWithPath: #filePath)
            .deletingLastPathComponent()
            .deletingLastPathComponent()
            .deletingLastPathComponent()
            .appendingPathComponent("Fixtures/VAO03/valid/embedded-private")
    }

    private var descriptors: URL {
        URL(fileURLWithPath: #filePath)
            .deletingLastPathComponent()
            .deletingLastPathComponent()
            .deletingLastPathComponent()
            .appendingPathComponent("Fixtures/VAO03/descriptors")
    }

    private var acousticFixture: URL {
        URL(fileURLWithPath: #filePath)
            .deletingLastPathComponent()
            .deletingLastPathComponent()
            .deletingLastPathComponent()
            .appendingPathComponent("Fixtures/VAO03/valid/acousticrooms-scene")
    }

    private func writeAcousticArchive(to destination: URL, corruptRIR: Bool = false) throws {
        let manager = FileManager.default
        let payload = acousticFixture.appendingPathComponent("payload", isDirectory: true)
        let payloadFiles = try XCTUnwrap(manager.enumerator(
            at: payload,
            includingPropertiesForKeys: [.isRegularFileKey],
            options: [.skipsHiddenFiles]
        )).compactMap { $0 as? URL }.filter {
            (try? $0.resourceValues(forKeys: [.isRegularFileKey]).isRegularFile) == true
        }.sorted { $0.path < $1.path }
        var entries = [
            VAOArchiveEntrySource(path: "mimetype", fileURL: acousticFixture.appendingPathComponent("mimetype")),
            VAOArchiveEntrySource(path: VAO03Contract.manifestFilename, fileURL: acousticFixture.appendingPathComponent(VAO03Contract.manifestFilename)),
            VAOArchiveEntrySource(path: VAO03Contract.carrierFilename, fileURL: acousticFixture.appendingPathComponent(VAO03Contract.carrierFilename)),
        ]
        for file in payloadFiles {
            let relative = "payload/" + String(file.standardizedFileURL.path.dropFirst(payload.standardizedFileURL.path.count + 1))
            if corruptRIR, relative.hasSuffix("S000_R0011_hybrid_IR.wav") {
                entries.append(VAOArchiveEntrySource(path: relative, data: Data("corrupt RIR".utf8)))
            } else {
                entries.append(VAOArchiveEntrySource(path: relative, fileURL: file))
            }
        }
        try VAOArchiveWriter.write(entries: entries, to: destination)
    }

    func testRepositoryFreeVAO03FixtureIsValid() throws {
        let data = try Data(contentsOf: fixture.appendingPathComponent(VAO03Contract.manifestFilename))
        XCTAssertEqual(VAOFormatDispatcher.formatVersion(in: data), "0.3.2")
        XCTAssertEqual(VAO03Validator.validateManifest(data: data), [])
        let manifest = try VAOFormatDispatcher.decode03(data)
        XCTAssertTrue(manifest.distributions.isEmpty)
        XCTAssertTrue(manifest.repositoryBindings.isEmpty)
        XCTAssertFalse(manifest.profiles.contains { $0.id == VAO03Contract.zenodoProfile })
    }

    func testCarrierPinsManifestAndEmbeddedRealization() throws {
        let manifest = try Data(contentsOf: fixture.appendingPathComponent(VAO03Contract.manifestFilename))
        let carrier = try Data(contentsOf: fixture.appendingPathComponent(VAO03Contract.carrierFilename))
        let evidence = try Data(contentsOf: fixture.appendingPathComponent("payload/evidence/source.txt"))
        XCTAssertEqual(VAO03Validator.validateCarrier(
            manifestData: manifest,
            carrierData: carrier,
            embeddedData: ["payload/evidence/source.txt": evidence]
        ), [])
    }

    func testZenodoProfileCannotBeClaimedWithoutBinding() throws {
        let data = try Data(contentsOf: fixture.appendingPathComponent(VAO03Contract.manifestFilename))
        var manifest = try VAOFormatDispatcher.decode03(data)
        manifest.profiles.append(VAO03Profile(id: VAO03Contract.zenodoProfile, version: "0.3", requiredCapabilities: []))
        let errors = VAO03Validator.validateManifest(manifest)
        XCTAssertTrue(errors.contains { $0.contains("if and only if") })
    }

    func testGroupDependencyCycleIsRejected() throws {
        let data = try Data(contentsOf: fixture.appendingPathComponent(VAO03Contract.manifestFilename))
        var manifest = try VAOFormatDispatcher.decode03(data)
        manifest.assetGroups[0].dependsOnGroupIds = [manifest.assetGroups[0].id]
        let errors = VAO03Validator.validateManifest(manifest)
        XCTAssertTrue(errors.contains { $0.contains("dependency graph contains a cycle") })
    }

    func testDuplicateRegistryIdentifierIsReportedWithoutTrapping() throws {
        let data = try Data(contentsOf: fixture.appendingPathComponent(VAO03Contract.manifestFilename))
        var manifest = try VAOFormatDispatcher.decode03(data)
        manifest.assetGroups.append(manifest.assetGroups[0])
        let errors = VAO03Validator.validateManifest(manifest)
        XCTAssertTrue(errors.contains { $0.contains("not unique") })
    }

    func testMaterializationPlannerKeepsRepositoryUseOptional() throws {
        let data = try Data(contentsOf: fixture.appendingPathComponent(VAO03Contract.manifestFilename))
        let carrierData = try Data(contentsOf: fixture.appendingPathComponent(VAO03Contract.carrierFilename))
        let manifest = try VAOFormatDispatcher.decode03(data)
        let carrier = try JSONDecoder().decode(VAO03Carrier.self, from: carrierData)
        let plan = try VAO03MaterializationPlanner.plan(
            manifest: manifest,
            carrier: carrier,
            requestedGroupIds: [manifest.assetGroups[0].id],
            supportedCapabilities: []
        )
        XCTAssertEqual(plan.embeddedRealizationIds.count, 1)
        XCTAssertTrue(plan.remoteRealizationIds.isEmpty)
        XCTAssertEqual(plan.totalByteSize, 69)
    }

    func testSingleRecordPublicationAndZenodoMetadataAreCoherent() throws {
        let releaseData = try Data(contentsOf: descriptors.appendingPathComponent("release-single-record.example.json"))
        let metadataData = try Data(contentsOf: descriptors.appendingPathComponent("zenodo-metadata-single-record.example.json"))
        let release = try JSONDecoder().decode(VAO03ReleaseDescriptor.self, from: releaseData)
        let metadata = try JSONDecoder().decode(VAO03ZenodoMetadataDocument.self, from: metadataData)
        XCTAssertEqual(VAO03Validator.validateReleaseDescriptor(data: releaseData), [])
        XCTAssertEqual(VAO03Validator.validatePublication(release, zenodoMetadata: [metadata]), [])
        XCTAssertEqual(release.publication.topology, "single-record")
        XCTAssertTrue(release.publication.familyMembers.isEmpty)
    }

    func testRecordFamilyRequiresExactProjectedRelations() throws {
        let release = try JSONDecoder().decode(
            VAO03ReleaseDescriptor.self,
            from: Data(contentsOf: descriptors.appendingPathComponent("release-record-family.example.json"))
        )
        let names = [
            "zenodo-metadata-family-root.example.json",
            "zenodo-metadata-family-model.example.json",
            "zenodo-metadata-family-audio.example.json",
        ]
        var metadata = try names.map {
            try JSONDecoder().decode(VAO03ZenodoMetadataDocument.self, from: Data(contentsOf: descriptors.appendingPathComponent($0)))
        }
        XCTAssertEqual(VAO03Validator.validatePublication(release, zenodoMetadata: metadata), [])
        metadata[0].metadata.relatedIdentifiers.removeFirst()
        XCTAssertTrue(VAO03Validator.validatePublication(release, zenodoMetadata: metadata).contains { $0.contains("lacks hasPart relation") })
    }

    func testPublicAcousticRoomsSceneIsPositionRegisteredAndValid() throws {
        let data = try Data(contentsOf: acousticFixture.appendingPathComponent(VAO03Contract.manifestFilename))
        XCTAssertEqual(VAO03Validator.validateManifest(data: data), [])
        let manifest = try VAOFormatDispatcher.decode03(data)
        let acoustics = try XCTUnwrap(manifest.acoustics?.objectValue)
        let poses = try XCTUnwrap(acoustics["poses"]?.arrayValue)
        XCTAssertEqual(poses[0].objectValue?["position"]?.arrayValue?.compactMap(\.numberValue), [2.3496, 0.7269, 1.353])
        XCTAssertEqual(poses[1].objectValue?["position"]?.arrayValue?.compactMap(\.numberValue), [2.8176, 0.9871, 1.4665])
        XCTAssertEqual(manifest.realizations.first { $0.mediaType == "audio/wav" }?.technicalMetadata.impulseResponse?.objectValue?["sampleCount"]?.integerValue, 11_864)
    }

    func testPublicAcousticRoomsPreservationCarrierClosesAllBytes() throws {
        let manifestData = try Data(contentsOf: acousticFixture.appendingPathComponent(VAO03Contract.manifestFilename))
        let carrierData = try Data(contentsOf: acousticFixture.appendingPathComponent(VAO03Contract.carrierFilename))
        let carrier = try JSONDecoder().decode(VAO03Carrier.self, from: carrierData)
        let embedded = try Dictionary(uniqueKeysWithValues: carrier.embeddedRealizations.map { mapping in
            (mapping.path, try Data(contentsOf: acousticFixture.appendingPathComponent(mapping.path)))
        })
        XCTAssertEqual(embedded.count, 8)
        XCTAssertEqual(VAO03Validator.validateCarrier(manifestData: manifestData, carrierData: carrierData, embeddedData: embedded), [])
    }

    func testImpulseResponseChannelOutsideRealizationIsRejected() throws {
        let source = try Data(contentsOf: acousticFixture.appendingPathComponent(VAO03Contract.manifestFilename))
        var root = try XCTUnwrap(JSONSerialization.jsonObject(with: source) as? [String: Any])
        var realizations = try XCTUnwrap(root["realizations"] as? [[String: Any]])
        let audioIndex = try XCTUnwrap(realizations.firstIndex { ($0["mediaType"] as? String) == "audio/wav" })
        var realization = realizations[audioIndex]
        var technical = try XCTUnwrap(realization["technicalMetadata"] as? [String: Any])
        var impulse = try XCTUnwrap(technical["impulseResponse"] as? [String: Any])
        var mappings = try XCTUnwrap(impulse["measurementMappings"] as? [[String: Any]])
        mappings[0]["channelIndices"] = [1]
        impulse["measurementMappings"] = mappings
        technical["impulseResponse"] = impulse
        realization["technicalMetadata"] = technical
        realizations[audioIndex] = realization
        root["realizations"] = realizations
        let data = try JSONSerialization.data(withJSONObject: root)
        XCTAssertTrue(VAO03Validator.validateManifest(data: data).contains { $0.contains("outside channelCount") })
    }

    func testVisualAcousticSceneRequiresTransformableGeometry() throws {
        let source = try Data(contentsOf: acousticFixture.appendingPathComponent(VAO03Contract.manifestFilename))
        var root = try XCTUnwrap(JSONSerialization.jsonObject(with: source) as? [String: Any])
        var acoustics = try XCTUnwrap(root["acoustics"] as? [String: Any])
        var frames = try XCTUnwrap(acoustics["coordinateFrames"] as? [[String: Any]])
        frames[1]["transformToParent"] = Array(repeating: 0, count: 16)
        acoustics["coordinateFrames"] = frames
        root["acoustics"] = acoustics
        let data = try JSONSerialization.data(withJSONObject: root)
        XCTAssertTrue(VAO03Validator.validateManifest(data: data).contains { $0.contains("invertible transformToParent") })
    }

    func testOrgRecInspectsImportsAndExtractsVAO032AcousticCarrier() async throws {
        let root = FileManager.default.temporaryDirectory
            .appendingPathComponent("orgrec-vao032-reader-\(UUID().uuidString)", isDirectory: true)
        try FileManager.default.createDirectory(at: root, withIntermediateDirectories: true)
        defer { try? FileManager.default.removeItem(at: root) }
        let archive = root.appendingPathComponent("acousticrooms.vao")
        try writeAcousticArchive(to: archive)

        let reader = VAO03PackageReader()
        let inspection = try await reader.inspect(archive)
        XCTAssertTrue(inspection.isValid, inspection.errors.joined(separator: "; "))
        XCTAssertEqual(inspection.verifiedPayloadBytes, 1_722_650)
        let scene = try XCTUnwrap(inspection.acousticScene)
        XCTAssertEqual(scene.coordinateFrames.count, 2)
        XCTAssertEqual(scene.poses.count, 2)
        XCTAssertEqual(scene.measurements.count, 1)
        XCTAssertEqual(scene.geometryResources.count, 2)
        XCTAssertEqual(scene.impulseResponseResources.count, 1)
        XCTAssertEqual(scene.impulseResponseResources[0].sampleCount, 11_864)
        XCTAssertEqual(scene.impulseResponseResources[0].embeddedPath, "payload/acoustics/S000_R0011_hybrid_IR.wav")

        let workspace = root.appendingPathComponent("workspace", isDirectory: true)
        _ = try await reader.importWorkspace(from: archive, to: workspace)
        XCTAssertEqual(
            try sha256(of: workspace.appendingPathComponent("payload/geometry/Bathrooms_idx_0.glb")),
            "03e1bb41f2db881da22212184baa765a71ae9e3248ef610237f67322b039798a"
        )
        let extracted = root.appendingPathComponent("rir.wav")
        try await reader.extractRealization(
            id: "urn:vao:fixture:acousticrooms:realization:rir:wav",
            from: archive,
            to: extracted
        )
        XCTAssertEqual(try sha256(of: extracted), "acfa34ce1f465e78337da0ac7032b92e2913dfa4203c077acd1e5cbe6dd446b6")
    }

    func testOrgRecStreamingReaderRejectsCorruptVAO032Payload() async throws {
        let root = FileManager.default.temporaryDirectory
            .appendingPathComponent("orgrec-vao032-corrupt-\(UUID().uuidString)", isDirectory: true)
        try FileManager.default.createDirectory(at: root, withIntermediateDirectories: true)
        defer { try? FileManager.default.removeItem(at: root) }
        let archive = root.appendingPathComponent("corrupt.vao")
        try writeAcousticArchive(to: archive, corruptRIR: true)
        let inspection = try await VAO03PackageReader().inspect(archive)
        XCTAssertFalse(inspection.isValid)
        XCTAssertTrue(inspection.errors.contains { $0.contains("fails fixity") })
    }
}
